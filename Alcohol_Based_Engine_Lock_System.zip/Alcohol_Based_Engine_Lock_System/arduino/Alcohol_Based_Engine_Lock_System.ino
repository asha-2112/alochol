/*
  Alcohol-Based Engine Lock System
  Educational IoT prototype: MQ-3 sensor + Arduino + relay demo output.

  SAFETY:
  - The relay must control only a low-voltage demonstration load.
  - Never connect this prototype to a real vehicle ignition or fuel system.
  - MQ-3 readings are relative, uncalibrated values, not BAC measurements.
*/

const int ALCOHOL_SENSOR_PIN = A0;
const int RELAY_PIN          = 8;
const int BUZZER_PIN         = 7;
const int GREEN_LED_PIN      = 5;
const int RED_LED_PIN        = 6;

// Tune only for a controlled demonstration after observing the sensor baseline.
const int ALCOHOL_THRESHOLD = 400;
const unsigned long WARMUP_TIME_MS = 30000UL;
const int SAMPLE_COUNT = 10;

// Many relay modules are active-low. Set false for active-high modules.
const bool RELAY_ACTIVE_LOW = true;

unsigned long startupTime;
bool warmupComplete = false;

void setDemoRelay(bool enabled) {
  // enabled = demo load/indicator may run; disabled = simulated lock.
  if (RELAY_ACTIVE_LOW) {
    digitalWrite(RELAY_PIN, enabled ? LOW : HIGH);
  } else {
    digitalWrite(RELAY_PIN, enabled ? HIGH : LOW);
  }
}

int readAveragedSensor() {
  long total = 0;
  for (int i = 0; i < SAMPLE_COUNT; i++) {
    total += analogRead(ALCOHOL_SENSOR_PIN);
    delay(20);
  }
  return (int)(total / SAMPLE_COUNT);
}

void showLockedState() {
  setDemoRelay(false);
  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(RED_LED_PIN, HIGH);
  digitalWrite(BUZZER_PIN, HIGH);
}

void showEnabledState() {
  setDemoRelay(true);
  digitalWrite(GREEN_LED_PIN, HIGH);
  digitalWrite(RED_LED_PIN, LOW);
  digitalWrite(BUZZER_PIN, LOW);
}

void setup() {
  pinMode(RELAY_PIN, OUTPUT);
  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(GREEN_LED_PIN, OUTPUT);
  pinMode(RED_LED_PIN, OUTPUT);
  pinMode(ALCOHOL_SENSOR_PIN, INPUT);

  // Fail-safe startup: keep the simulated load disabled during warm-up.
  setDemoRelay(false);
  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(GREEN_LED_PIN, LOW);
  digitalWrite(RED_LED_PIN, HIGH);

  Serial.begin(9600);
  startupTime = millis();

  Serial.println(F("Alcohol-Based Engine Lock System"));
  Serial.println(F("Educational demo only; not for vehicle ignition."));
  Serial.println(F("Sensor warming up; simulated load remains LOCKED."));
}

void loop() {
  int sensorValue = readAveragedSensor();

  if (!warmupComplete) {
    unsigned long elapsed = millis() - startupTime;
    if (elapsed < WARMUP_TIME_MS) {
      setDemoRelay(false);
      digitalWrite(GREEN_LED_PIN, LOW);
      digitalWrite(RED_LED_PIN, HIGH);
      digitalWrite(BUZZER_PIN, LOW);

      Serial.print(F("WARMING UP | elapsed_ms="));
      Serial.print(elapsed);
      Serial.print(F(" | sensor="));
      Serial.println(sensorValue);
      delay(500);
      return;
    }
    warmupComplete = true;
    Serial.println(F("Warm-up timer complete. Demo monitoring started."));
  }

  Serial.print(F("Sensor reading: "));
  Serial.print(sensorValue);
  Serial.print(F(" | threshold: "));
  Serial.print(ALCOHOL_THRESHOLD);

  if (sensorValue >= ALCOHOL_THRESHOLD) {
    showLockedState();
    Serial.println(F(" | STATUS: LOCKED - threshold exceeded"));
  } else {
    showEnabledState();
    Serial.println(F(" | STATUS: ENABLED - below threshold"));
  }

  delay(300);
}
