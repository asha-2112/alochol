# Project Overview

## Objective
Create an IoT demonstration that senses alcohol vapour and uses a controller to switch a simulated engine-enable output between enabled and locked states.

## Problem statement
Driving after alcohol consumption can create serious safety risks. This prototype demonstrates the core idea of sensor-based interlocking: when the sensor reading crosses a configured threshold, the controller disables a demonstration output and alerts the user.

## Proposed architecture
1. **Sensing layer:** MQ-3 alcohol sensor module provides an analog signal.
2. **Processing layer:** Arduino Uno averages multiple samples and compares the result with a configurable threshold.
3. **Actuation layer:** Relay module switches a low-voltage demo load only.
4. **Alert layer:** Red/green LEDs and buzzer indicate the current state.
5. **Monitoring layer:** Serial Monitor displays readings and status.

## Expected demonstration
- Below threshold: green LED on, red LED off, buzzer off, demo output enabled.
- At/above threshold: red LED on, green LED off, buzzer on, demo output disabled.
- During startup warm-up: demo output stays disabled.

## Evaluation checklist
- [ ] Sensor values appear in the Serial Monitor.
- [ ] Warm-up state keeps the demo output disabled.
- [ ] A low reading produces the enabled indication.
- [ ] A reading at or above the configured threshold produces the locked indication.
- [ ] Relay logic matches the module's active-high/active-low behaviour.
- [ ] No connection is made to a real vehicle or mains-voltage circuit.

## Important caveats
The MQ-3 is a semiconductor gas sensor, not a certified breathalyser. A raw analog threshold cannot establish blood-alcohol concentration or legal impairment. This is a learning prototype only.
